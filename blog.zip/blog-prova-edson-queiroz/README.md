# Blog - Prova 2 Grupo Edson Queiroz

#### Para Instalar: 
- composer update
- php artisan make:migration posts
- php artisan make:migration comments
- php artisan migrate
- php -S localhost:8888 -t public
