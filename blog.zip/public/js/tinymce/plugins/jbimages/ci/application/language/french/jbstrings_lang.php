<?php

$lang['jb_blankpage_message'] = "Le processus de téléchargement n\'a pas encore commencé"; // Google translate))

/* End of file jbstrings_lang.php */
/* Location: ./application/language/french/jbstrings_lang.php */
